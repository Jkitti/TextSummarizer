////Author: James Kitti
////CSV files must be in src/main/java/data/Csvs
////Outputs to src/main/java/data/Averages

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class RougeAvgCalc {

	    public static void main(String[] args) throws IOException {

	    	
	    	//Import Csvs.
		    File dir = new File("C:/Users/JKitt/workspace/Csv_Reader/src/main/java/data/Csvs");
		    File[] directoryListing = dir.listFiles();
		    if (directoryListing != null) {
		      for (File child : directoryListing) {
		    	  String childName = "";
		    	  StringTokenizer nt = new StringTokenizer(child.getName(), ",.:?! \t\n\r" );
		    	  while (nt.hasMoreTokens()) {
		    		  String nametoken = (String) nt.nextToken();
	    			     if(nametoken.equals("csv")){
	    			         break;
	    			     }
	    			     else{
	    			    	 childName = childName + nametoken;
	    			     }
		    	  }
		    	  String line = "";
		    	  String cvsSplitBy = ",";
		    	  int linenum = 0;
		    	  double sum = 0;
		    	  double psum = 0;
		    	  ArrayList<String> rougevalues = new ArrayList();
		    	  ArrayList<String> percision = new ArrayList();
		    	  try (BufferedReader br = new BufferedReader(new FileReader(child))) {
		    		  while ((line = br.readLine()) != null) {
	                // use comma as separator
		    			  String[] values = line.split(cvsSplitBy);
		    			  if (linenum > 0 ){
		    				  	rougevalues.add(values[4]);
		    				  	percision.add(values[5]);
		    				  	linenum += 1;
		    			  }
		    			  else{
		    				  linenum += 1;
		    				  continue;
		    			  }
		    		  }
		    		  br.close();
		    	  }
		    	  catch (FileNotFoundException e){
		    	  e.printStackTrace();
		    	  } 
		    	  catch (IOException e) {
		    		e.printStackTrace();
		    	  }
		    	  for(String s : rougevalues){
		    		  sum+=Double.parseDouble(s);
		    	  	}
		    	  for(String s : percision){
		    		  psum+=Double.parseDouble(s);
		    	  	}
		    	  FileWriter fw = null;
		    	  double average = sum/rougevalues.size();
		    	  double peravg = psum/rougevalues.size();
		    	   try{    
		    	        fw = new FileWriter("C:/Users/JKitt/workspace/Csv_Reader/src/main/java/data/Averages/" + childName + ".txt");    
		    	        fw.write("The average rouge value of " + childName + " is: " + average + "\n" + "The average percision is:  " + peravg);       
		    	        }
		    	   catch(Exception e){
		    		   System.out.println(e);
		    	        }
		    	   finally {
		    		   fw.close();
		    		}  
	        }

	    }
	}
}
